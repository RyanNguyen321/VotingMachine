import sun.awt.image.ImageWatched;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class ElectionData {
  private HashMap<String, Integer> Hash1 = new HashMap<String, Integer>();
  private HashMap<String, Integer> Hash2 = new HashMap<String, Integer>();
  private HashMap<String, Integer> Hash3 = new HashMap<String, Integer>();

  ElectionData()
  {
  }

  /**
   * Registers a vote of three choices, checks if vote is valid
   * @param choice1 First choice on vote
   * @param choice2 Second choice on vote
   * @param choice3 Third choice on vote
   * @throws UnknownCandidateException If candidate voted for doesn't exist
   * @throws DuplicateVotesException If voted for same candidate
   */
    public void processVote(String choice1,String choice2,String choice3) throws UnknownCandidateException, DuplicateVotesException
    {
      LinkedList<String> temp = new LinkedList<>();
      temp.add(choice1);
      temp.add(choice2);
      temp.add(choice3);

      for (String element: temp) //check name
      {
        if (Hash1.containsKey(element) == false)
        {
          throw new UnknownCandidateException(element);
        }
      }

      //Checks for duplicates
      if (choice1.equals(choice2))
      {
        throw new DuplicateVotesException(choice1);
      }

      else if (choice2.equals(choice3))
      {
        throw new DuplicateVotesException(choice1);
      }

      else if (choice1.equals(choice3))
      {
        throw new DuplicateVotesException(choice1);
      }

      else
      {
        Hash1.replace(choice1, (Hash1.get(choice1)+1 ));
        Hash2.replace(choice2, (Hash2.get(choice2)+1 ));
        Hash3.replace(choice3, (Hash3.get(choice3)+1 ));
      }
    }

  /**
   * Adds a candidate to the ballot
   * @param name Name of candidate to be added
   * @throws CandidateExistsException If candidate already exists
   */
    public void addCandidate(String name) throws CandidateExistsException
    {
      if (Hash1.containsKey(name) == false)
      {
        Hash1.put(name,0);
        Hash2.put(name,0);
        Hash3.put(name,0);
      }
      else
      {
        throw new CandidateExistsException(name);
      }
    }

  /**
   * Calculates the winner who has >50% of first place votes
   * @return Winner, or runoff required if winner can't be calculated
   */
  public String findWinnerMostFirstVotes()
    {
      double totalVotes = 0.0;
      double highestVotes = 0.0;
      String highestCandidate = "";
      boolean check = false;

      LinkedList<String> keys = new LinkedList<String>(Hash1.keySet());

      for (String element: keys)
      {
        totalVotes += Hash1.get(element);

        if (Hash1.get(element) == highestVotes) //checks if there is a tie
        {
          check = true;
        }

        if (Hash1.get(element) > highestVotes) //checks if votes are higher than current highest
        {
          highestVotes = Hash1.get(element);
          highestCandidate = element;
          check = false;
        }
      }

      if (check == true)
      {
        return "Runoff required";
      }
      if (highestVotes/totalVotes >= .5) //> 50% of votes
      {
        return highestCandidate;
      }
      return "Runoff required";

    }

  /**
   * Calculates the winner based on their amount of points
   * @return Winner who has the most points
   */
  public String findWinnerMostPoints()
    {
      LinkedList<String> keys = new LinkedList<String>(Hash1.keySet());
      String highestCandidate = "";
      int highestPoints = 0;

      for (String element: keys)
      {
        int count = 0;
        count = ((Hash1.get(element)*3) + (Hash2.get(element)*2) + (Hash3.get(element)*1));
        if (count > highestPoints)
        {
          highestPoints = count;
          highestCandidate = element;
        }
      }

      return highestCandidate;
    }

  /**
   * Gets the current ballot of votes and returns it
   * @return Returns current ballot
   */
  public LinkedList<String> getBallot()
    {
      return new LinkedList<String>(Hash1.keySet());
    }


  }
