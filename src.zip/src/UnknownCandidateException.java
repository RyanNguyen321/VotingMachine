class UnknownCandidateException extends Exception{
    private String name;

    UnknownCandidateException(String name){
        this.name = name;
    }

    /**
     * Gets name
     * @return returns name of candidate
     */
    public String getName() {
        return this.getName();
    }
}