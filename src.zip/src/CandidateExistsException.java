class CandidateExistsException extends Exception {
    private String name;

    CandidateExistsException(String name){
        this.name = name;
    }

    /**
     * Gets name
     * @return returns name of candidate
     */
    public String getName() {
        return this.getName();
    }
}