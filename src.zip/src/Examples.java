import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.assertEquals;

public class Examples {


    ElectionData Setup1 () {

        ElectionData ED = new ElectionData();


        try {

            ED.addCandidate("gompei");
            ED.addCandidate("husky");
            ED.addCandidate("ziggy");

        } catch (Exception e) {}


        try {

            ED.processVote("gompei", "husky", "ziggy");
            ED.processVote("gompei", "ziggy", "husky");
            ED.processVote("husky", "gompei", "ziggy");

        } catch (Exception e) {}

        return(ED);

    }

    @Test
    public void testMostFirstWinner_1() {
        assertEquals ("gompei", Setup1().findWinnerMostFirstVotes());
    }

    @Test
    public void testFindWinnerMostPoints_1()
    {
        assertEquals("gompei", Setup1().findWinnerMostPoints());
    }

    @Test
    public void getBallotTest_1()
    {
        LinkedList<String> temp = new LinkedList<>();
        temp.add("ziggy");
        temp.add("husky");
        temp.add("gompei");
        assertEquals(temp,Setup1().getBallot());
    }

    @Test(expected = DuplicateVotesException.class)
    public void testProcessVote_1() throws DuplicateVotesException, UnknownCandidateException {
        Setup1().processVote("ziggy","ziggy","husky");
    }


    ElectionData Setup2 () throws DuplicateVotesException, UnknownCandidateException {

        ElectionData ED = new ElectionData();

        try {

            ED.addCandidate("gompei");
            ED.addCandidate("husky");
            ED.addCandidate("ziggy");

        } catch (Exception e) {}


        try {

            ED.processVote("gompei", "gompei", "ziggy");
            ED.processVote("gompei", "ziggy", "husky");
            ED.processVote("husky", "gompei", "ziggy");
            ED.processVote("husky", "gompei", "randomrandom");

        } catch (Exception e)
        {
            System.out.println("Unknown candidate");
            throw e;
        }

        return(ED);

    }

    @Test
    public void testMostFirstWinner_2() {
        assertEquals ("gompei", Setup1().findWinnerMostFirstVotes());
    }

    @Test
    public void testFindWinnerMostPoints_2()
    {
        assertEquals("gompei", Setup1().findWinnerMostPoints());
    }

    @Test
    public void getBallotTest_2()
    {
        LinkedList<String> temp = new LinkedList<>();
        temp.add("ziggy");
        temp.add("husky");
        temp.add("gompei");
        assertEquals(temp,Setup1().getBallot());
    }


    ElectionData Setup3 () throws DuplicateVotesException, UnknownCandidateException {

        ElectionData ED = new ElectionData();

        try {

            ED.addCandidate("gompei");
            ED.addCandidate("husky");
            ED.addCandidate("ziggy");

        } catch (Exception e) {}


        try {

            ED.processVote("gompei", "gompei", "ziggy");
            ED.processVote("gompei", "ziggy", "husky");
            ED.processVote("husky", "husky", "ziggy");

        } catch (Exception e)
        {
            System.out.println("Same candidate voted");
            throw e;
        }

        return(ED);

    }

    @Test
    public void testMostFirstWinner_3() {
        assertEquals ("gompei", Setup1().findWinnerMostFirstVotes());
    }

    @Test
    public void testFindWinnerMostPoints_3()
    {
        assertEquals("gompei", Setup1().findWinnerMostPoints());
    }

    @Test
    public void getBallotTest_3()
    {
        LinkedList<String> temp = new LinkedList<>();
        temp.add("ziggy");
        temp.add("husky");
        temp.add("gompei");
        assertEquals(temp,Setup1().getBallot());
    }

}
