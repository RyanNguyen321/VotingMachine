import java.util.Scanner;

class VotingMachine {
    Scanner keyboard = new Scanner(System.in);
    ElectionData electionData;

    VotingMachine()
    {
        electionData = new ElectionData();
    }

    /**
     * Prints out the ballots
     */
    public void printBallot() {
        System.out.println("Ballot candidates: ");
        System.out.println(electionData.getBallot());
    }


    public void screen() throws UnknownCandidateException, DuplicateVotesException, CandidateExistsException {
        this.printBallot();
        System.out.println("Vote for round 1: ");
        String candidate1 = keyboard.next();
        System.out.println("You voted for " + candidate1);

        System.out.println("Vote for round 2: ");
        String candidate2 = keyboard.next();
        System.out.println("You voted for " + candidate2);

        System.out.println("Vote for round 1: ");
        String candidate3 = keyboard.next();
        System.out.println("You voted for " + candidate3);

        try{
            electionData.processVote(candidate1,candidate2,candidate3);
        }

        catch(DuplicateVotesException e){
            System.out.println("You can not vote for the same candidate twice");

        }

        catch(UnknownCandidateException e)
        {
            System.out.println("Would you like to add the candidate's name to the ballot(Y/N)? ");
            String check = keyboard.next();
            if (check.equals("Y") || check.equals("y"))
            {
                addWriteIn(e.getName());
            }
        }


    }

    /**
     * Add a candidate into election from the voting machine interface
     * @param name Name of candidate to be added
     * @throws CandidateExistsException If a candidate already exists on the current ballot
     */
    public void addWriteIn(String name) throws CandidateExistsException {
        try{
            electionData.addCandidate(name);
        }

        catch(CandidateExistsException e)
        {
            System.out.println("Candidate already exists");
        }
    }
}